import 'package:flutter/material.dart';
import '../services/transaction_service.dart';
import 'transaction_screen.dart';

class HomeScreen extends StatefulWidget {
  final String userName;
  HomeScreen({required this.userName});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TransactionService service = TransactionService();
  String receiverId = '2';
  double amount = 0;

  @override
  Widget build(BuildContext context) {
    final user = service.users.firstWhere((u) => u.name == widget.userName, orElse: () => service.users.first);
    return Scaffold(
      appBar: AppBar(title: Text('Hello, ${user.name}')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Balance: \$${user.balance}', style: TextStyle(fontSize: 24)),
            SizedBox(height: 20),
            TextField(
              decoration: InputDecoration(labelText: 'Receiver ID'),
              onChanged: (v) => receiverId = v,
            ),
            TextField(
              decoration: InputDecoration(labelText: 'Amount'),
              keyboardType: TextInputType.number,
              onChanged: (v) => amount = double.tryParse(v) ?? 0,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text('Send Money'),
              onPressed: () {
                bool success = service.sendMoney(user.id, receiverId, amount);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(success ? 'Transaction Successful!' : 'Insufficient Balance'),
                ));
                setState(() {});
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text('View Transactions'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => TransactionScreen(service: service)),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
