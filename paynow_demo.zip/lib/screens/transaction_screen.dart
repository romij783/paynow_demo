import 'package:flutter/material.dart';
import '../services/transaction_service.dart';

class TransactionScreen extends StatelessWidget {
  final TransactionService service;
  TransactionScreen({required this.service});

  @override
  Widget build(BuildContext context) {
    final txs = service.getTransactions();
    return Scaffold(
      appBar: AppBar(title: Text('Transactions')),
      body: ListView.builder(
        itemCount: txs.length,
        itemBuilder: (_, i) {
          final tx = txs[i];
          return ListTile(
            title: Text('${tx.senderId} → ${tx.receiverId}'),
            subtitle: Text('\$${tx.amount} - ${tx.time.toLocal()}'),
          );
        },
      ),
    );
  }
}
