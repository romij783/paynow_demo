class TransactionModel {
  String senderId;
  String receiverId;
  double amount;
  DateTime time;

  TransactionModel({
    required this.senderId,
    required this.receiverId,
    required this.amount,
    required this.time,
  });
}
