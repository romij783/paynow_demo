class User {
  String id;
  String name;
  double balance;

  User({required this.id, required this.name, required this.balance});
}
