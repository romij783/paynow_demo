import '../models/user.dart';
import '../models/transaction.dart';

class TransactionService {
  List<User> users = [
    User(id: '1', name: 'Romij', balance: 1000),
    User(id: '2', name: 'Hasan', balance: 800),
  ];

  List<TransactionModel> transactions = [];

  bool sendMoney(String senderId, String receiverId, double amount) {
    User sender = users.firstWhere((u) => u.id == senderId);
    User receiver = users.firstWhere((u) => u.id == receiverId);

    if (sender.balance >= amount) {
      sender.balance -= amount;
      receiver.balance += amount;
      transactions.add(TransactionModel(
        senderId: senderId,
        receiverId: receiverId,
        amount: amount,
        time: DateTime.now(),
      ));
      return true;
    } else {
      return false;
    }
  }

  List<TransactionModel> getTransactions() => transactions;
}
