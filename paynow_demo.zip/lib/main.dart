import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(PayNowApp());
}

class PayNowApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PayNow Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.green),
      home: LoginScreen(),
    );
  }
}
